const body = document.body;
const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");

if (menuToggle && mainNav) {
  menuToggle.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    body.classList.toggle("menu-open", open);
    menuToggle.setAttribute("aria-expanded", String(open));
    menuToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });

  mainNav.querySelectorAll(".nav-item").forEach((item) => {
    const dropdown = item.querySelector(".dropdown");
    const link = item.querySelector(".nav-link");
    if (dropdown && link) {
      link.addEventListener("click", (event) => {
        if (window.innerWidth <= 1100) {
          event.preventDefault();
          item.classList.toggle("expanded");
        }
      });
    }
  });
}

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.1 }
);

document.querySelectorAll(".reveal").forEach((element) => revealObserver.observe(element));

document.querySelectorAll("[data-filter-group]").forEach((group) => {
  const targetSelector = group.dataset.target;
  const cards = document.querySelectorAll(targetSelector);

  group.querySelectorAll("[data-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      group.querySelectorAll("[data-filter]").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      const filter = button.dataset.filter;
      cards.forEach((card) => {
        const categories = card.dataset.category || "";
        card.classList.toggle("hidden", filter !== "all" && !categories.split(" ").includes(filter));
      });
    });
  });
});

const projectModal = document.querySelector(".project-modal");
if (projectModal) {
  const modalImage = projectModal.querySelector(".modal-image img");
  const modalTitle = projectModal.querySelector("[data-modal-title]");
  const modalText = projectModal.querySelector("[data-modal-text]");
  const modalSpecs = projectModal.querySelectorAll("[data-modal-spec]");

  document.querySelectorAll("[data-project]").forEach((card) => {
    card.addEventListener("click", () => {
      modalImage.src = card.dataset.image;
      modalImage.alt = card.dataset.title;
      modalTitle.textContent = card.dataset.title;
      modalText.textContent = card.dataset.description;
      const specs = [card.dataset.size, card.dataset.style, card.dataset.city];
      modalSpecs.forEach((spec, index) => {
        spec.textContent = specs[index];
      });
      projectModal.classList.add("open");
      projectModal.setAttribute("aria-hidden", "false");
      body.style.overflow = "hidden";
    });
  });

  const closeModal = () => {
    projectModal.classList.remove("open");
    projectModal.setAttribute("aria-hidden", "true");
    body.style.overflow = "";
  };

  projectModal.querySelector(".modal-close").addEventListener("click", closeModal);
  projectModal.addEventListener("click", (event) => {
    if (event.target === projectModal) closeModal();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && projectModal.classList.contains("open")) closeModal();
  });
}

const calculator = document.querySelector("[data-calculator]");
if (calculator) {
  const steps = [...calculator.querySelectorAll(".calc-step")];
  const progressSteps = [...calculator.querySelectorAll(".progress-step")];
  let currentStep = 0;

  const showStep = (index) => {
    currentStep = Math.max(0, Math.min(index, steps.length - 1));
    steps.forEach((step, stepIndex) => step.classList.toggle("active", stepIndex === currentStep));
    progressSteps.forEach((step, stepIndex) => step.classList.toggle("active", stepIndex <= currentStep));
  };

  calculator.querySelectorAll("[data-next]").forEach((button) => {
    button.addEventListener("click", () => showStep(currentStep + 1));
  });
  calculator.querySelectorAll("[data-prev]").forEach((button) => {
    button.addEventListener("click", () => showStep(currentStep - 1));
  });

  const fileInput = calculator.querySelector("#design-file");
  const fileLabel = calculator.querySelector("[data-file-label]");
  if (fileInput && fileLabel) {
    fileInput.addEventListener("change", () => {
      fileLabel.textContent = fileInput.files.length ? fileInput.files[0].name : "Click to upload PDF, DWG, JPG or PNG";
    });
  }

  calculator.addEventListener("submit", (event) => {
    event.preventDefault();
    showStep(steps.length - 1);
    const confirmation = calculator.querySelector(".submit-confirmation");
    if (confirmation) confirmation.hidden = false;
  });
}

document.querySelectorAll("form[data-demo-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const status = form.querySelector("[data-status]");
    if (status) status.textContent = "Thank you — your brief has been received.";
  });
});
