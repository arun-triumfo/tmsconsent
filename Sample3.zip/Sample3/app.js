const body = document.body;
const burger = document.querySelector(".burger");
const nav = document.querySelector(".nav");

if (burger && nav) {
  burger.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    body.classList.toggle("nav-open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });

  nav.querySelectorAll(".nav-item").forEach((item) => {
    const link = item.querySelector(".nav-link");
    const drop = item.querySelector(".drop");
    if (link && drop) {
      link.addEventListener("click", (e) => {
        if (window.innerWidth <= 1100) {
          e.preventDefault();
          item.classList.toggle("open");
        }
      });
    }
  });
}

const revealObs = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("show");
        revealObs.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12 }
);
document.querySelectorAll(".reveal").forEach((el) => revealObs.observe(el));

document.querySelectorAll("[data-filter-group]").forEach((group) => {
  const target = group.dataset.target;
  const cards = document.querySelectorAll(target);
  group.querySelectorAll("[data-filter]").forEach((btn) => {
    btn.addEventListener("click", () => {
      group.querySelectorAll("[data-filter]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const filter = btn.dataset.filter;
      cards.forEach((card) => {
        const cats = (card.dataset.category || "").split(" ");
        card.classList.toggle("hidden", filter !== "all" && !cats.includes(filter));
      });
    });
  });
});

const modal = document.querySelector(".modal");
if (modal) {
  const img = modal.querySelector(".modal-img img");
  const title = modal.querySelector("[data-m-title]");
  const text = modal.querySelector("[data-m-text]");
  const challenge = modal.querySelector("[data-m-challenge]");
  const solution = modal.querySelector("[data-m-solution]");
  const specs = modal.querySelectorAll("[data-m-spec]");

  const close = () => {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    body.style.overflow = "";
  };

  document.querySelectorAll("[data-project]").forEach((card) => {
    card.addEventListener("click", () => {
      img.src = card.dataset.image;
      img.alt = card.dataset.title;
      title.textContent = card.dataset.title;
      text.textContent = card.dataset.description;
      if (challenge) challenge.textContent = card.dataset.challenge || "";
      if (solution) solution.textContent = card.dataset.solution || "";
      [card.dataset.size, card.dataset.style, card.dataset.city].forEach((val, i) => {
        if (specs[i]) specs[i].textContent = val;
      });
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      body.style.overflow = "hidden";
    });
  });

  modal.querySelector(".modal-close").addEventListener("click", close);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.classList.contains("open")) close();
  });
}

const calc = document.querySelector("[data-calc]");
if (calc) {
  const steps = [...calc.querySelectorAll(".calc-step")];
  const progress = [...calc.querySelectorAll(".p-step")];
  let current = 0;

  const show = (i) => {
    current = Math.max(0, Math.min(i, steps.length - 1));
    steps.forEach((s, idx) => s.classList.toggle("active", idx === current));
    progress.forEach((s, idx) => s.classList.toggle("active", idx <= current));
  };

  calc.querySelectorAll("[data-next]").forEach((btn) => {
    btn.addEventListener("click", () => show(current + 1));
  });
  calc.querySelectorAll("[data-prev]").forEach((btn) => {
    btn.addEventListener("click", () => show(current - 1));
  });

  const file = calc.querySelector("#design-file");
  const fileLabel = calc.querySelector("[data-file-label]");
  if (file && fileLabel) {
    file.addEventListener("change", () => {
      fileLabel.textContent = file.files.length
        ? file.files[0].name
        : "Click to upload PDF, DWG, JPG or PNG";
    });
  }

  calc.addEventListener("submit", (e) => {
    e.preventDefault();
    const ok = calc.querySelector("[data-confirm]");
    if (ok) ok.hidden = false;
  });
}

document.querySelectorAll("form[data-demo]").forEach((form) => {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const status = form.querySelector("[data-status]");
    if (status) status.textContent = "Thank you — your brief has been received.";
  });
});
